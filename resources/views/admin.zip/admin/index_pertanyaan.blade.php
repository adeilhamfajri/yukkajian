@extends('admin.layout_admin')
@section('content')
	@include('admin.panel')
	@include('admin.top_navigation')
	@include('admin.pertanyaan.data_pertanyaan')
@endsection