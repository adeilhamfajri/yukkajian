@extends('admin.layout_admin')
@section('content')
	@include('admin.panel')
	@include('admin.top_navigation')
	@include('admin.kajian.data_kajian')
@endsection