<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left"><h3>Home</h3></div>
    </div>