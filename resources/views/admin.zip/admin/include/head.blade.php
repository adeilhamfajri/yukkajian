{!! Html::style(asset('css_admin/bootstrap.min.css')) !!}
{!! Html::style(asset('css_admin/font-awesome.min.css')) !!}
{!! Html::style(asset('css_admin/nprogress.css')) !!}
{!! Html::style(asset('css_admin/green.css')) !!}
{!! Html::style(asset('css_admin/prettify.min.css')) !!}
{!! Html::style(asset('css_admin/select2.min.css')) !!}
{!! Html::style(asset('css_admin/switchery.min.css')) !!}
{!! Html::style(asset('css_admin/starrr.css')) !!}
{!! Html::style(asset('css_admin/daterangepicker.css')) !!}
{!! Html::style(asset('css_admin/custom.min.css')) !!}


{!! Html::style(asset('css_admin/dataTables.bootstrap.min.css')) !!}
{!! Html::style(asset('css_admin/buttons.bootstrap.min.css')) !!}
{!! Html::style(asset('css_admin/fixedHeader.bootstrap.min.css')) !!}
{!! Html::style(asset('css_admin/responsive.bootstrap.min.css')) !!}
{!! Html::style(asset('css_admin/scroller.bootstrap.min.css')) !!}

{!! Html::style(asset('css_admin/normalize.css')) !!}
{!! Html::style(asset('css_admin/cropper.min.css')) !!}
