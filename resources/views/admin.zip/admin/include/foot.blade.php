{!! Html::script('js_admin/jquery.min.js') !!}
{!! Html::script('js_admin/bootstrap.min.js') !!}
{!! Html::script('js_admin/fastclick.js') !!}
{!! Html::script('js_admin/nprogress.js') !!}
{!! Html::script('js_admin/bootstrap-progressbar.min.js') !!}
{!! Html::script('js_admin/icheck.min.js') !!}
{!! Html::script('js_admin/moment.min.js') !!}
{!! Html::script('js_admin/daterangepicker.js') !!}
{!! Html::script('js_admin/bootstrap-wysiwyg.min.js') !!}
{!! Html::script('js_admin/jquery.hotkeys.js') !!}
{!! Html::script('js_admin/prettify.js') !!}
{!! Html::script('js_admin/jquery.tagsinput.js') !!}
{!! Html::script('js_admin/switchery.min.js') !!}
{!! Html::script('js_admin/select2.full.min.js') !!}
{!! Html::script('js_admin/parsley.min.js') !!}
{!! Html::script('js_admin/autosize.min.js') !!}
{!! Html::script('js_admin/jquery.autocomplete.min.js') !!}
{!! Html::script('js_admin/starrr.js') !!}
{!! Html::script('js_admin/custom.min.js') !!}


{!! Html::script('js_admin/jquery.dataTables.min.js') !!}
{!! Html::script('js_admin/dataTables.bootstrap.min.j') !!}
{!! Html::script('js_admin/dataTables.buttons.min.js') !!}
{!! Html::script('js_admin/buttons.bootstrap.min.js') !!}
{!! Html::script('js_admin/buttons.flash.min.js') !!}
{!! Html::script('js_admin/buttons.html5.min.js') !!}
{!! Html::script('js_admin/buttons.print.min.js') !!}
{!! Html::script('js_admin/dataTables.fixedHeader.min.js') !!}
{!! Html::script('js_admin/dataTables.keyTable.min.js') !!}
{!! Html::script('js_admin/dataTables.responsive.min.js') !!}
{!! Html::script('js_admin/responsive.bootstrap.js') !!}
{!! Html::script('js_admin/dataTables.scroller.min.js') !!}
{!! Html::script('js_admin/jszip.min.js') !!}
{!! Html::script('js_admin/pdfmake.min.js') !!}
{!! Html::script('js_admin/vfs_fonts.js') !!}

<!-- {!! Html::script('js_admin/cropper.min.js') !!} -->
{!! Html::script('js_admin/jquery.inputmask.bundle.min.js') !!}

